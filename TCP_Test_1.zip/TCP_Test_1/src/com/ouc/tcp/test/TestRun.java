package com.ouc.tcp.test;

import com.ouc.tcp.app.SystemStart;

public class TestRun {
	
	public static void main(String[] args) throws InterruptedException {
		SystemStart.main(null);
	}
	
}
